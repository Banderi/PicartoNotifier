analytics = false;
if (chrome) {
	storage = chrome.storage;
	tabs = chrome.tabs;
	notifications = chrome.notifications;
	analytics = false;
}
function isDevMode() {
    return !('update_url' in chrome.runtime.getManifest());
}

// open streaming page from popup link
function openStreamer(name) {
	window.open('https://picarto.tv/' + name, '_blank');
	notifications.clear(name, function() {});
	window.close();
	if (analytics) {
		_gaq.push(['_trackEvent', 'Action', 'PopupLinkRoute']);
	}
}

// main update function
function updateNames() {
	var streaming = false;
	var multistream = false;
	
	var streamer = localStorage["streamer"];
	if (!streamer) {
		streamer = "false";
	}
	
	storage.local.get(null, function(items) {
		$('body').find('.con_live').empty();
		$('body').find('.con_invites').empty();
	
		var keys = Object.keys(items);
		keys.forEach(function(key, index) {
			
			if (key == "MULTISTREAM_SESSION") {
				if (items[key][0] && streamer == "true") {
					multistream = true;
					
					// add invites
					for (index in items[key]) {
						
						// received pending invite
						if (items[key][index]["status"] == "received") { 
							$('body').find('.con_invites').append(
								$('<div/>', {'class': 'conn_invite'}).append(
									$('<div/>', {'class': 'conn_streamer_head'}).append(
										$('<div/>', {'class': 'col'}).append(
											$('<img/>', {'class': 'conn_avatar'}).attr("src", "https://picarto.tv/user_data/usrimg/" + items[key][index]["name"].toLowerCase() + "/dsdefault.jpg")
										)
										.append(
											$('<span/>', {'class': 'conn_user', text: "Invite from " + items[key][index]["name"]})
										)
										.append(
											$('<span/>', {'class': 'ms_button ms_acc', 'value': items[key][index]["id"]}).append(
												$('<i/>', {'class': 'icon'}).html('&#xe812;')
											)
										)
										.append(
											$('<span/>', {'class': 'ms_button ms_dec', 'value': items[key][index]["id"]}).append(
												$('<i/>', {'class': 'icon'}).html('&#xe813;')
											)
										)
									)
								)
							);
						}
						// attending multistream session
						else if (items[key][index]["status"] == "attending") {
							$('body').find('.con_invites').append(
								$('<div/>', {'class': 'conn_invite'}).append(
									$('<div/>', {'class': 'conn_streamer_head'}).append(
										$('<div/>', {'class': 'col'}).append(
											$('<img/>', {'class': 'conn_avatar'}).attr("src", "https://picarto.tv/user_data/usrimg/" + items[key][index]["name"].toLowerCase() + "/dsdefault.jpg")
										)
										.append(
											$('<span/>', {'class': 'conn_user', text: items[key][index]["name"] + " (active)"})
										)
										.append(
											$('<span/>', {'class': 'ms_button ms_dec', 'value': items[key][index]["id"]}).append(
												$('<i/>', {'class': 'icon'}).html('&#xe813;')
											)
										)
									)
								)
							);
						}
						// sent pending invite
						else if (items[key][index]["status"] == "sent") {
							$('body').find('.con_invites').append(
								$('<div/>', {'class': 'conn_invite'}).append(
									$('<div/>', {'class': 'conn_streamer_head'}).append(
										$('<div/>', {'class': 'col'}).append(
											$('<img/>', {'class': 'conn_avatar'}).attr("src", "https://picarto.tv/user_data/usrimg/" + items[key][index]["name"].toLowerCase() + "/dsdefault.jpg")
										)
										.append(
											$('<span/>', {'class': 'conn_user', text: "Awaiting..."})
										)
										.append(
											$('<span/>', {'class': 'ms_button ms_rev', 'value': items[key][index]["id"]}).append(
												$('<i/>', {'class': 'icon'}).html('&#xe813;')
											)
										)
									)
								)
							);
						}
						// hosting multistream session
						else if (items[key][index]["status"] == "hosting") {
							$('body').find('.con_invites').append(
								$('<div/>', {'class': 'conn_invite'}).append(
									$('<div/>', {'class': 'conn_streamer_head'}).append(
										$('<div/>', {'class': 'col'}).append(
											$('<img/>', {'class': 'conn_avatar'}).attr("src", "https://picarto.tv/user_data/usrimg/" + items[key][index]["name"].toLowerCase() + "/dsdefault.jpg")
										)
										.append(
											$('<span/>', {'class': 'conn_user', text: items[key][index]["name"] + " (hosting)"})
										)
										.append(
											$('<span/>', {'class': 'ms_button ms_rev', 'value': items[key][index]["id"]}).append(
												$('<i/>', {'class': 'icon'}).html('&#xe813;')
											)
										)
									)
								)
							);
						}
						
					}
				}
			}
			else if (items[key]) {
				streaming = true;
				
				// add link to the window
				$('body').find('.con_live').append(
					$('<div/>', {'class': 'conn_streamer', 'id': key}).append(
						$('<div/>', {'class': 'conn_streamer_head'}).append(
							$('<div/>', {'class': 'col'}).append(
								$('<img/>', {'class': 'conn_avatar'}).attr("src", "https://picarto.tv/user_data/usrimg/" + key.toLowerCase() + "/dsdefault.jpg")
							)
							.append(
								$('<span/>', {'class': 'conn_user', text: key})
							)
						)
					)
				);
			}
		});
		if (streaming) {
			$('body').find('.con_headings').text("Currently streaming:");
		}
		// loop through links
		var links = $('body').find('.conn_streamer');
		if (isDevMode()) {
			console.log("links are: " + links.length);
		}
		links.each(function() {
			var name = $(this).attr('id');
			if (isDevMode()) {
				console.log($(this) + " : " + name);
			}
			
			// register the link
			document.getElementById(name).addEventListener('click', function() {
				openStreamer(name);
			});
		});
		
		if (streamer == "true") {
			if (isDevMode()) {
				console.log("(Streamer mode is enabled.)");
			}
			$('body').find('.con_multi').show();
			
			if (multistream) {
				$('body').find('.con_multi').text("Current multistream sessions:");
			}
			// loop through invite accept/decline/revoke buttons
			var decline = $('body').find('.ms_dec');
			decline.each(function() {
				var inv = $(this);
				var id = $(this).attr('value');
				if (isDevMode()) {
					console.log($(this).parent().children().eq(1).text() + " : " + id);
				}
				
				// register the uninvite button
				$(this).on('click', function() {
					$.post("https://picarto.tv/process/settings/multistream", {type: "multistream", leaveMultistream: id}, function(data) {}, "json").done(function(data) {
						if (data.multistreamLeft == 1) {
							if (isDevMode()) {
								console.log("Refusing multistream...");
							}
							inv.parent().parent().parent().remove();
							//clearInterval(updater);
							//var updater = setInterval(updateNames, 5000);
							storage.local.get("MULTISTREAM_SESSION", function(items) {
								for (index in items["MULTISTREAM_SESSION"]) {
									if (items["MULTISTREAM_SESSION"][index]["id"] == id) {
										delete(items["MULTISTREAM_SESSION"][index]);
										storage.local.set({"MULTISTREAM_SESSION":items["MULTISTREAM_SESSION"]}, function() {});
									}
								}
							});
						}
					}).fail(function() {
						console.log("Whoops. it failed!");
					});
				}).on('mouseover', function() {
					$(this).parent().parent().parent().css("background-color", "rgba(116, 57, 52, 0.95)")
				}).on('mouseout', function() {
					$(this).parent().parent().parent().css("background-color", "#5b616c")
				});
			});
			var accept = $('body').find('.ms_acc');
			accept.each(function() {
				var inv = $(this);
				var id = $(this).attr('value');
				
				// register the accept button
				$(this).on('click', function() {
					$.post("https://picarto.tv/process/settings/multistream", {type: "multistream", acceptInvitation: id}, function(data) {}, "json").done(function(data) {
						if (isDevMode()) {
							console.log("Accepting multistream...");
						}
						if (data.privatemode == 1) {
							//displayNotificationMsg(33)
						} else {
							switch (data.invitationAccepted) {
								case 1:
									inv.parent().parent().parent().remove();
									// var app = "<span class='ms_invites'><div class='ms_inv_name'><img class='ms_avatar' src='../user_data/usrimg/"
									// + data.channel.toLowerCase() + "/dsdefault.jpg'>"
									// + data.channel + "</div><div class='ms_hov_1'><span class='ms_dec leave_ms' title='leave' value='"
									// + data.userIdFromInvitedChannel + "'><i class='icon-cancel'></i></span></div></span>";
									// $("#ms_acc_div").append(app);
									
									//clearInterval(updater);
									//var updater = setInterval(updateNames, 5000);
									storage.local.get("MULTISTREAM_SESSION", function(items) {
										for (index in items["MULTISTREAM_SESSION"]) {
											if (items["MULTISTREAM_SESSION"][index]["id"] == id) {
												delete(items["MULTISTREAM_SESSION"][index]);
												storage.local.set({"MULTISTREAM_SESSION":items["MULTISTREAM_SESSION"]}, function() {});
											}
										}
									});
									break;
								case "alreadyAccepted":
									//displayNotificationMsg(22);
									break;
								case "channelError":
									//displayNotificationMsg(20);
									break;
								case "updateError":
									//displayErrorMsg(225);
									break;
								default:
									//displayErrorMsg(226)
							}
						}
					}).fail(function() {
						console.log("Whoops. it failed!");
					});
				}).on('mouseover', function() {
					$(this).parent().parent().parent().css("background-color", "rgba(95, 116, 52, 0.95)")
				}).on('mouseout', function() {
					$(this).parent().parent().parent().css("background-color", "#5b616c")
				});
			});
			var revoke = $('body').find('.ms_rev');
			revoke.each(function() {
				var inv = $(this);
				var id = $(this).attr('value');
				if (isDevMode()) {
					console.log($(this).parent().children().eq(1).text() + " : " + id);
				}
				
				// register the uninvite button
				$(this).on('click', function() {
					$.post("https://picarto.tv/process/settings/multistream", {type: "multistream", removeMultistream: id}, function(data) {}, "json").done(function(data) {
						if (data.removed == 1) {
							if (isDevMode()) {
								console.log("Revoking session...");
							}
							inv.parent().parent().parent().remove();
							//clearInterval(updater);
							//var updater = setInterval(updateNames, 5000);
							storage.local.get("MULTISTREAM_SESSION", function(items) {
								for (index in items["MULTISTREAM_SESSION"]) {
									if (items["MULTISTREAM_SESSION"][index]["id"] == id) {
										delete(items["MULTISTREAM_SESSION"][index]);
										storage.local.set({"MULTISTREAM_SESSION":items["MULTISTREAM_SESSION"]}, function() {});
									}
								}
							});
						}
					}).fail(function() {
						console.log("Whoops. it failed!");
					});
				}).on('mouseover', function() {
					$(this).parent().parent().parent().css("background-color", "rgba(116, 57, 52, 0.95)")
				}).on('mouseout', function() {
					$(this).parent().parent().parent().css("background-color", "#5b616c")
				});
			});
		}
		else {
			if (isDevMode()) {
				console.log("(Streamer mode is disabled.)");
			}
			$('body').find('.con_multi').hide();
		}
	});
	if (analytics) {
		_gaq.push(['_trackEvent', 'PopupSession', 'Update']);
	}
}

// register Google Analytics pageview (doesn't work on FireFox)
if (analytics) {
var _gaq = _gaq || [];
_gaq.push(['_setAccount', 'UA-84261296-1']);
_gaq.push(['_trackEvent', 'PopupSession', 'Startup']);

(function() {
  var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
  ga.src = 'https://ssl.google-analytics.com/ga.js';
  var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
})();
}

// update popup window
$(document).ready(function() {
	updateNames();
	//clearInterval(updater);
	var updater = setInterval(updateNames, 5000);
	if (isDevMode()) {
		console.log("updated!");
	}
});