analytics = false;
if (chrome) {
	extension = chrome.extension;
	browser = chrome;
	analytics = false;
}

// save settings to local storage
function save_options() {
	var select = document.getElementById("update");
	var update = select.children[select.selectedIndex].value;
	localStorage["update"] = update;
	
	select = document.getElementById("notifications");
	var notifications = select.checked.toString();
	localStorage["notifications"] = notifications;
	
	select = document.getElementById("alert");
	var alert = select.checked.toString();
	localStorage["alert"] = alert;
	
	select = document.getElementById("streamer");
	var streamer = select.checked.toString();
	localStorage["streamer"] = streamer;
	
	var status = document.getElementById("status");
	status.textContent = "Options Saved.";
	setTimeout(function() {
		status.textContent = "";
	}, 750);
	
	browser.runtime.sendMessage( {message: "settingChanged", update: update, notifications: notifications, alert: alert, streamer: streamer} );
	
	if (analytics) {
		_gaq.push(['_trackEvent', 'OptionsSession', 'ChangedSettings']);
	}
}

// update text and buttons
function page_load() {
	var save = document.getElementById("save");
	save.onclick = save_options;
	
	// update interval
	var update = localStorage["update"];
	if (!update) {
		update = "300000";
	}
	var select = document.getElementById("update");
	for (var i = 0; i < select.children.length; i++) {
		var child = select.children[i];
		if (child.value == update) {
			child.selected = "true";
			break;
		}
	}
	
	// desktop notifications
	var notifications = localStorage["notifications"];
	if (!notifications) {
		notifications = "true";
	}
	select = document.getElementById("notifications");
	select.checked = (notifications == "true");
	select.onchange = refresh;
	
	// notification sounds
	var alert = localStorage["alert"];
	if (!alert) {
		alert = "false";
	}
	select = document.getElementById("alert");
	select.checked = (alert == "true");
	select.disabled = !(notifications == "true");
	
	// streamer options
	var streamer = localStorage["streamer"];
	if (!streamer) {
		streamer = "false";
	}
	select = document.getElementById("streamer");
	select.checked = (streamer == "true");
	
	if (analytics) {
		_gaq.push(['_trackEvent', 'OptionsSession', 'Update']);
	}
}

// refresh some content after linked settings changed
function refresh() {
	select = document.getElementById("alert");
	select.disabled = !document.getElementById("notifications").checked;
}

// register Google Analytics pageview (doesn't work on FireFox)
if (analytics) {
var _gaq = _gaq || [];
_gaq.push(['_setAccount', 'UA-84261296-1']);
_gaq.push(['_trackEvent', 'OptionsSession', 'Startup']);

(function() {
  var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
  ga.src = 'https://ssl.google-analytics.com/ga.js';
  var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
})();
}

window.onload = page_load;