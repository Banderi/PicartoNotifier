analytics = false;
if (chrome) {
	storage = chrome.storage;
	tabs = chrome.tabs;
	notifications = chrome.notifications;
	browser = chrome;
	analytics = true;
}
function isDevMode() {
    return !('update_url' in chrome.runtime.getManifest());
}

// listen for messages from other pages
browser.runtime.onMessage.addListener(
	function(request, sender, sendResponse) {
		if (request.message == "setCount")
		{
			setCount(request.count);
		}
		else if (request.message == "settingChanged")
		{
			clearInterval(updater);
			updater = setInterval(updateCount, request.update);
			notifications = request.notifications;
			alert = request.alert;
		}
		else if (request.message == "getFullStorage")
		{
			if (isDevMode()) {
				console.log("getFullStorage");
			}
			storage.local.get(null, function(items) {
				sendResponse(items);
			});
			return true;
		}
		else if (request.message == "getBadgeText")
		{
			if (isDevMode()) {
				console.log("getBadgeText");
			}
			browser.browserAction.getBadgeText({}, function(result) {
				sendResponse(result);
			});
			return true;
		}
		return false;
	}
);

// main update function
function updateCount() {
	$.ajax({
		url: "https://picarto.tv/settings/connections",
		success: function(data) {
			if (isDevMode()) {
				console.log("Updating...");
			}
			
			// check user session
			storage.local.get("ACCOUNT_SESSION_USERNAME", function(item) {
				if ($(data).find('.usermenu_username').text() !== item["ACCOUNT_SESSION_USERNAME"]) {
					storage.local.clear();
				}
				
				parser = new DOMParser();
				doc = parser.parseFromString(data, "text/html");	
				if (isDevMode()) {
					console.log("DOCParser replied with username: '" + $(doc).find('.usermenu_username').text() + "'");
				}
				storage.local.set({"ACCOUNT_SESSION_USERNAME" : $(doc).find('.usermenu_username').text()});
				
				var users = [];			
				var count = 0;
				
				var parse;
				
				// update currently followed
				storage.local.get(null, function(items) {
					parse = $(data).find('.conn_user');
					
					// loop through current saved users
					for (key in items) {
						if (key == "ACCOUNT_SESSION_USERNAME") {
							continue;
						}
						followed_user = key;
						
						var is_followed = false;
						
						parse.each(function(index) {
							var name = $(this).text();
							var team = $(this).closest(".col-xs-12").find(".con_headings").children().eq(0);
							
							// check if followed team
							if (team.text() !== "Following") {
								return true;
							}
							
							if (name === followed_user) {
								is_followed = true;
							}
						});
						
						// check if user is followed
						if (!is_followed) {
							if (isDevMode()) {
								console.log("WARNING: '" + followed_user + "' is not in the follow list - will be removed!");
							}
							
							// remember name for async procedures
							var remove_name = followed_user;
							
							storage.local.remove(remove_name, function() {
								if (isDevMode()) {
									console.log(remove_name + " removed from the storage list!");
								}
							});
						}
					}
				});
				
				// update currently streaming
				parse = $(data).find('.onlineLabel');				
				parse.each(function(index) {
					var name = $(this).parent().parent().find('.col-xs-7').find('.conn_user').text();
					
					var team = $(this).closest(".col-xs-12").find(".con_headings").children().eq(0);
					if (isDevMode()) {
						console.log("team: " + team.text());
					}
					
					// check if followed
					if (team.text() !== "Following") {
						return true;
					}
					
					var user_item = {};
					
					// look for people live
					if ($(this).find('i').length) {
						user_item[name] = 1;
						
						// update badge counter
						if ($.inArray(name, users) == -1) {
							users.push(name);
							count += 1;
							
							// dispatch streaming notification/alert
							storage.local.get(name, function(item) {
								if (item[name] != 1) {
									if (notifications == "true") {										
										browser.notifications.create(name, {
											type: 'basic',
											iconUrl: 'icons/icon128.png',
											title: 'Currently streaming on Picarto:',
											message: name
										}, function() {});
										if (alert == "true") {
											ding.play();
										}
										if (analytics) {
											_gaq.push(['_trackEvent', 'BackgroundSession', 'Alert']);
										}
									}
								}
							});
						}
					} else {
						user_item[name] = 0;
					}
					storage.local.set(user_item);
				});
				
				if (isDevMode()) {
					browser.browserAction.setBadgeBackgroundColor( { color: "#33aa33"} );
				}
				
				// update badge text
				if (count == 1) {
					browser.browserAction.setBadgeText( {"text": "1"} );
					browser.browserAction.setTitle( {"title": "1 person currently streaming!"} );
				} else if (count > 1) {
					browser.browserAction.setBadgeText( {"text": count.toString()} );
					browser.browserAction.setTitle( {"title": count.toString() + " people currently streaming!"} );
				} else {
					browser.browserAction.setBadgeText( {"text": ""} );
					browser.browserAction.setTitle( {"title": "Nobody is currently streaming"} );
				}				
			});
			
			// push Google Analytics refresh
			if (analytics) {
				_gaq.push(['_trackEvent', 'BackgroundSession', 'Update', update]);
			}
			
			if (isDevMode()) {
				console.log("Update!");
			}
		},
		error: function() {
			browser.browserAction.setBadgeText( {"text": "??"} );
			browser.browserAction.setTitle( {"title": "Error updating!"} );
			console.log("--Error updating!--");
		}
	});
}

// fetch saved settings or generate default ones
var update = localStorage["update"];
if (!update) {
	update = "300000";
}
var updater = setInterval(updateCount, update);

var notifications = localStorage["notifications"];
if (!notifications) {
	notifications = "true";
}

var alert = localStorage["alert"];
if (!alert) {
	alert = "false";
}

// create audio alert object
var ding = new Audio('audio/ding.ogg');

// add listener to the desktop notification popups
browser.notifications.onClicked.addListener(function(notificationId) {
	if (isDevMode()) {
		console.log("Notification clicked! ID: " + notificationId);
	}
	window.open('https://picarto.tv/' + notificationId, '_blank');
	browser.notifications.clear(notificationId, function() {});
	if (analytics) {
		_gaq.push(['_trackEvent', 'Action', 'NotificationRoute']);
	}
});

// register Google Analytics (doesn't work on FireFox)
if (analytics) {
var _gaq = _gaq || [];
_gaq.push(['_setAccount', 'UA-84261296-1']);
_gaq.push(['_trackEvent', 'BackgroundSession', 'Startup']);

(function() {
  var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
  ga.src = 'https://ssl.google-analytics.com/ga.js';
  var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
})();
}
// start the update!
updateCount();