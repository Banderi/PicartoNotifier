analytics = false;
if (chrome) {
	storage = chrome.storage;
	tabs = chrome.tabs;
	notifications = chrome.notifications;
	analytics = true;
}
function isDevMode() {
    return !('update_url' in chrome.runtime.getManifest());
}

// open streaming page from popup
function openStreamer(name) {
	window.open('https://picarto.tv/' + name, '_blank');
	notifications.clear(name, function() {});
	window.close();
	if (analytics) {
		_gaq.push(['_trackEvent', 'Action', 'PopupLinkRoute']);
	}
}

// main update function
function updateNames() {
	var streaming = false;
	storage.local.get(null, function(items) {
		var keys = Object.keys(items);
		keys.forEach(function(key, index) {
			if (items[key] == 1) {
				streaming = true;
				
				// add link to the window
				$('body').append(
					$('<div/>', {'class': 'conn_option', 'id': key}).append(
						$('<div/>', {'class': 'conn_option_head'}).append(
							$('<div/>', {'class': 'col'}).append(
								$('<img/>', {'class': 'conn_avatar'}).attr("src", "https://picarto.tv/user_data/usrimg/" + key.toLowerCase() + "/dsdefault.jpg")
							)
							.append(
								$('<span/>', {'class': 'conn_user', text: key})
							)
						)
					)
				);
			}
		});
		if (streaming) {
			$('body').find('.con_headings').text("Currently streaming:");
		}
		var links = $('body').find('.conn_option');
		if (isDevMode()) {
			console.log("links are: " + links.length);
		}
		links.each(function(index) {
			var name = $(this).attr('id');
			if (isDevMode()) {
				console.log($(this) + " : " + name);
			}
			
			// register the link
			document.getElementById(name).addEventListener('click', function() {
				openStreamer(name);
			});
		});
	});
	if (analytics) {
		_gaq.push(['_trackEvent', 'PopupSession', 'Update']);
	}
}

// register Google Analytics pageview (doesn't work on FireFox)
if (analytics) {
var _gaq = _gaq || [];
_gaq.push(['_setAccount', 'UA-84261296-1']);
_gaq.push(['_trackEvent', 'PopupSession', 'Startup']);

(function() {
  var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
  ga.src = 'https://ssl.google-analytics.com/ga.js';
  var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
})();
}

// update popup window
$(document).ready(function() {
	updateNames();
	if (isDevMode()) {
		console.log("updated!");
	}
});